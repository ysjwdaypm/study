
def show(n):
	print "name:" + n