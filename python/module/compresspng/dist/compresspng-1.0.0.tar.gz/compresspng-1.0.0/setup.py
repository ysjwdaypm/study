
from distutils.core import setup

setup(
	name="compresspng",
	version="1.0.0",
	py_modules=["tools","compresspng","pngquant"]
)