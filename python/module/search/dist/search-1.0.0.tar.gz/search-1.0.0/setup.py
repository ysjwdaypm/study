
from distutils.core import setup

setup(
	name="search",
	version="1.0.0",
	py_modules=["search"]
)